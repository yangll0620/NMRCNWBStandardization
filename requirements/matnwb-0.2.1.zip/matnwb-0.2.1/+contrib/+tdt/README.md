# TDT NWB UTILS

`TDTbin2mat.m` is TDT software for reading TDT files into MATLAB. 