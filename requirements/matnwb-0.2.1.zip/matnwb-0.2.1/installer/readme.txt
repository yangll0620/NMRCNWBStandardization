Generating the Installer
------------------------
1. Install Inno Setup (http://www.jrsoftware.org/isinfo.php)
2. Open up setupNWB.iss using Inno Setup
3. Compile (compiled executables automatically go into the Output directory)
